package com.bipin.bai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.ContactsContract;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout chat;
    private TextView status;
    private SpeechRecognizer sr;
    private Intent speechIntent;
    private TextToSpeech tts;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean active = false, speaking = false, confirmCall = false;
    private String number = "", person = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE}, 1);
        }
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN"));
        });
        prepareSpeechIntent();
        createRecognizer();
        addMessage("Lakshmi", "नमस्ते! बोलिए, क्या करना है?");
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(14, 14, 14, 14);
        root.setBackgroundColor(0xff10131a);
        TextView title = new TextView(this);
        title.setText("B-Ai Advanced"); title.setTextSize(24); title.setTextColor(0xffffffff); title.setGravity(Gravity.CENTER);
        root.addView(title);
        status = new TextView(this);
        status.setText("तैयार"); status.setTextColor(0xff8fd3ff); status.setGravity(Gravity.CENTER);
        root.addView(status);
        ScrollView scroll = new ScrollView(this);
        chat = new LinearLayout(this); chat.setOrientation(LinearLayout.VERTICAL); scroll.addView(chat);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        Button start = new Button(this); start.setText("🎙 सुनना शुरू करें"); start.setOnClickListener(v -> startListeningLoop()); root.addView(start);
        Button stop = new Button(this); stop.setText("सुनना बंद करें"); stop.setOnClickListener(v -> stopListeningLoop()); root.addView(stop);
        setContentView(root);
    }

    private void prepareSpeechIntent() {
        speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
        speechIntent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false);
        speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 4);
    }

    private void createRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("Speech service उपलब्ध नहीं है");
            return;
        }
        if (sr != null) { try { sr.destroy(); } catch (Exception ignored) {} }
        sr = SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle b) { status.setText("सुन रही हूँ…"); }
            public void onBeginningOfSpeech() { status.setText("आवाज़ मिली"); }
            public void onRmsChanged(float x) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() { status.setText("समझ रही हूँ…"); }
            public void onError(int error) { handleSpeechError(error); }
            public void onResults(Bundle b) {
                ArrayList<String> results = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (results != null && !results.isEmpty()) handleCommand(results.get(0));
                else scheduleListen(400);
            }
            public void onPartialResults(Bundle b) {}
            public void onEvent(int type, Bundle b) {}
        });
    }

    private void handleSpeechError(int error) {
        if (!active) return;
        // Error 5 is ERROR_CLIENT: reset the recognizer instead of repeatedly
        // calling startListening() on a recognizer that may be in a bad state.
        if (error == SpeechRecognizer.ERROR_CLIENT) {
            status.setText("Speech service रीसेट हो रही है…");
            handler.postDelayed(() -> { if (active && !speaking) { createRecognizer(); scheduleListen(700); } }, 1200);
        } else if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
            status.setText("आवाज़ साफ़ नहीं मिली, फिर सुन रही हूँ…");
            scheduleListen(500);
        } else if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
            status.setText("Speech service व्यस्त है…");
            scheduleListen(1200);
        } else {
            status.setText("Speech error " + error + " — फिर कोशिश कर रही हूँ");
            scheduleListen(1000);
        }
    }

    private void startListeningLoop() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1); return;
        }
        active = true;
        if (sr == null) createRecognizer();
        scheduleListen(250);
    }

    private void stopListeningLoop() {
        active = false; handler.removeCallbacksAndMessages(null);
        if (sr != null) { try { sr.cancel(); } catch (Exception ignored) {} }
        status.setText("रुका हुआ");
    }

    private void scheduleListen(long delay) {
        handler.removeCallbacksAndMessages(null);
        if (!active || speaking || sr == null) return;
        handler.postDelayed(() -> {
            if (!active || speaking || sr == null) return;
            try { sr.startListening(speechIntent); }
            catch (Exception e) {
                status.setText("Speech service दोबारा शुरू हो रही है…");
                handler.postDelayed(() -> { if (active && !speaking) { createRecognizer(); scheduleListen(600); } }, 900);
            }
        }, delay);
    }

    private void handleCommand(String raw) {
        addMessage("आप", raw);
        String s = raw.toLowerCase(Locale.ROOT);
        if (confirmCall) {
            confirmCall = false;
            if (s.matches(".*(हाँ|हां|हा|yes|जी|ठीक).*")) makeCall();
            else speak("ठीक है, कॉल रद्द कर दी।");
            return;
        }
        if (s.contains("लक्ष्मी") || s.contains("lakshmi")) { speak("हाँ, बोलिए।"); return; }

        if (s.contains("कॉल") || s.contains("call")) {
            String name = raw.replaceAll("(?i)lakshmi|लक्ष्मी|call|कॉल|लगाओ|करो|फोन|कर दो", "").trim();
            findContact(name); return;
        }

        if (s.contains("youtube") || s.contains("यूट्यूब")) {
            String query = raw.replaceAll("(?i)lakshmi|लक्ष्मी|youtube|यूट्यूब|खोलो|ओपन|open|पर|चलाओ|करो", "").trim();
            if (query.isEmpty()) {
                if (launchApp("com.google.android.youtube")) speak("YouTube खोल रही हूँ।");
                else openUrl("https://www.youtube.com");
            } else openUrl("https://www.youtube.com/results?search_query=" + Uri.encode(query));
            return;
        }

        if (s.contains("whatsapp") || s.contains("व्हाट्सएप") || s.contains("व्हाट्स अप")) {
            if (launchApp("com.whatsapp")) speak("WhatsApp खोल रही हूँ। चैट चुनकर मैसेज भेजने से पहले जाँच लें।");
            else speak("WhatsApp इस फोन में इंस्टॉल नहीं मिला।");
            return;
        }

        if (s.contains("instagram") || s.contains("इंस्टाग्राम")) {
            if (launchApp("com.instagram.android")) speak("Instagram खोल रही हूँ।");
            else speak("Instagram इस फोन में इंस्टॉल नहीं मिला।");
            return;
        }

        if (s.contains("chrome") || s.contains("क्रोम")) {
            if (launchApp("com.android.chrome")) speak("Chrome खोल रही हूँ।");
            else speak("Chrome इस फोन में इंस्टॉल नहीं मिला।");
            return;
        }

        if (s.contains("google") || s.contains("गूगल") || s.contains("सर्च")) {
            String query = raw.replaceAll("(?i)lakshmi|लक्ष्मी|google|गूगल|search|सर्च|करो|खोलो|ओपन|open", "").trim();
            openUrl("https://www.google.com/search?q=" + Uri.encode(query)); return;
        }

        if (s.contains("map") || s.contains("मैप") || s.contains("रास्ता")) {
            String query = raw.replaceAll("(?i)lakshmi|लक्ष्मी|map|maps|मैप|रास्ता|बताओ|खोलो|ओपन|open", "").trim();
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(query)))); speak("Maps खोल रही हूँ।"); }
            catch (Exception e) { speak("Maps नहीं खुल पाया।"); }
            return;
        }

        if (s.contains("setting") || s.contains("सेटिंग")) {
            try { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); speak("Settings खोल रही हूँ।"); }
            catch (Exception e) { speak("Settings नहीं खुल पाई।"); }
            return;
        }
        speak("मैंने सुना: " + raw + "। इस कमांड को अभी जोड़ना बाकी है।");
    }

    private boolean launchApp(String packageName) {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
            if (launch == null) return false;
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
            return true;
        } catch (Exception e) { return false; }
    }

    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { speak("लिंक नहीं खुल पाया।"); }
    }

    private void findContact(String name) {
        if (name.isEmpty()) { speak("किसे कॉल करनी है?"); return; }
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER},
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", new String[]{"%" + name + "%"}, null);
            if (cursor != null && cursor.moveToFirst()) {
                person = cursor.getString(0); number = cursor.getString(1);
                confirmCall = true;
                speak(person + " के नंबर " + number + " पर कॉल लगाऊँ? हाँ या नहीं बोलिए।");
            } else speak("यह contact नहीं मिला।");
        } catch (Exception e) { speak("Contacts पढ़ने में समस्या है।"); }
        finally { if (cursor != null) cursor.close(); }
    }

    private void makeCall() {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            speak("कॉल करने की permission दीजिए।"); return;
        }
        try { startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number)))); }
        catch (Exception e) { try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)))); }
            catch (Exception ignored) { speak("कॉल नहीं लग पाई।"); } }
    }

    private void speak(String text) {
        addMessage("Lakshmi", text);
        if (tts == null) { scheduleListen(600); return; }
        speaking = true;
        String id = "bai" + System.currentTimeMillis();
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            public void onStart(String utteranceId) {}
            public void onDone(String utteranceId) { runOnUiThread(() -> { speaking = false; scheduleListen(500); }); }
            public void onError(String utteranceId) { runOnUiThread(() -> { speaking = false; scheduleListen(700); }); }
        });
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id);
    }

    private void addMessage(String who, String text) {
        TextView view = new TextView(this); view.setText(who + ": " + text); view.setTextColor(0xffffffff);
        view.setTextSize(16); view.setPadding(12, 10, 12, 10);
        view.setBackgroundColor(who.equals("आप") ? 0xff26384a : 0xff202833);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2); params.setMargins(0, 5, 0, 5);
        chat.addView(view, params);
    }

    @Override protected void onDestroy() {
        active = false; handler.removeCallbacksAndMessages(null);
        if (sr != null) { try { sr.destroy(); } catch (Exception ignored) {} }
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
