B-Ai Advanced v3.0 fresh Android Java project.
Build with Android Studio, JDK 17, Android Gradle Plugin 8.7.3, compile SDK 35.
Speech uses Android SpeechRecognizer and may require internet / installed Hindi speech services.
This prototype listens only while the app is open and user starts listening. It does not promise locked-screen always-on wake word.
Calling: looks up a contact, speaks its name and number, waits for spoken yes/no, then calls using SIM. Requires permission and cellular service.
WhatsApp: opens the app only; it does not read chats or send messages automatically.
No Gemini integration or API key included.
